import numpy as np

def precision_recall_f1(y_true, y_pred):
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    return precision, recall, f1, tp, fp, fn

def per_type_metrics(df, pred_col):
    rows = []
    for typ in ["spike", "dropout", "silent_drift"]:
        # Evaluate this anomaly type against all non-type rows.
        y_true = (df["anomaly_type"].values == typ).astype(int)
        y_pred = df[pred_col].values.astype(int)
        p, r, f1, tp, fp, fn = precision_recall_f1(y_true, y_pred)
        rows.append((typ, p, r, f1, tp, fp, fn))
    return rows
