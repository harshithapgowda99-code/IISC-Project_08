# Results So Far — Seed 0008 (numeric value 8)

## Dataset
- Rows: 7,200
- Resting baseline: 68 bpm
- Walking periods: 3
- Anomaly events: 20

## Question A — Isolation Forest
| Type | Precision | Recall | F1 |
|---|---:|---:|---:|
| Spike | 0.059 | 1.000 | 0.111 |
| Dropout | 0.047 | 0.253 | 0.080 |
| Silent drift | 0.002 | 0.001 | 0.002 |

Walking false alarms: **405**

## Question A — Custom NumPy detector
| Type | Precision | Recall | F1 |
|---|---:|---:|---:|
| Spike | 0.066 | 1.000 | 0.124 |
| Dropout | 0.142 | 0.679 | 0.235 |
| Silent drift | 0.739 | 0.317 | 0.444 |

Walking false alarms: **0**

The custom precision/recall/F1 values match sklearn for the same predictions.

## Question C — capacity
For 1,000 users:
- 1,000 writes/sec
- 86,400,000 rows/day
- ~241.40 GiB/month at an assumed 100 bytes/row

For 100,000 users:
- 100,000 writes/sec
- 8,640,000,000 rows/day
- ~24,139.88 GiB/month (~23.6 TiB)

## Important
The doubled-window Level-3 experiment is intentionally not included here because the
assignment requires the prediction to be committed before the experiment is run.
