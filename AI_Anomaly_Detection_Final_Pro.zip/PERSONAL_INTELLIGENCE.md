# Personal Intelligence Note

## Question A — decision 1
**Chosen:**  
**Rejected alternative:**  
**Why, using my own result:**  

## Question A — decision 2
**Chosen:**  
**Rejected alternative:**  
**Why, using my own result:**  

## Question C — decision 1
**Chosen:**  
**Rejected alternative:**  
**Why, using my own result:**  

## Question C — decision 2
**Chosen:**  
**Rejected alternative:**  
**Why, using my own result:**  

## AI usage declaration
AI tools used:

What I used them for:

One place where AI was wrong, weak, or incomplete:

How I found the issue:

How I fixed it:
