import argparse, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
from common_metrics import precision_recall_f1

def build_features(df):
    # Point + short-context features. shift(1) avoids leaking current point into prior mean.
    prior_mean = df["hr"].rolling(30, min_periods=5).mean().shift(1).bfill()
    prior_std = df["hr"].rolling(30, min_periods=5).std().shift(1).bfill().fillna(1.0)
    delta = df["hr"].diff().fillna(0)
    flatness = df["hr"].rolling(10, min_periods=2).std().fillna(0)
    return pd.DataFrame({
        "hr": df["hr"],
        "acc": df["acc"],
        "hr_delta": delta,
        "hr_vs_prior": df["hr"] - prior_mean,
        "prior_std": prior_std,
        "flatness10": flatness
    })

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, required=True)
    args = p.parse_args()

    df = pd.read_csv(ROOT/"setup"/"readings.csv")
    X = build_features(df)

    # Rough expected anomaly fraction from labelled event durations.
    contamination = min(0.12, max(0.01, float(df["label"].mean())))
    model = IsolationForest(
        n_estimators=250,
        contamination=contamination,
        random_state=args.seed
    )
    raw = model.fit_predict(X)
    df["iforest_pred"] = (raw == -1).astype(int)
    df["iforest_score"] = -model.score_samples(X)

    print(f"Isolation Forest contamination={contamination:.4f}")
    print("\nPer anomaly type (one-vs-rest point-level metrics):")
    for typ in ["spike", "dropout", "silent_drift"]:
        y_true = (df["anomaly_type"] == typ).astype(int)
        p, r, f1, *_ = precision_recall_f1(y_true, df["iforest_pred"])
        print(f"{typ:14s} precision={p:.3f} recall={r:.3f} f1={f1:.3f}")

    meta = json.loads((ROOT/"setup"/"metadata.json").read_text())
    walking_mask = np.zeros(len(df), dtype=bool)
    for start, end in meta["walking_periods"]:
        walking_mask[start:end+1] = True
    false_walking = int(df.loc[walking_mask, "iforest_pred"].sum())
    print(f"\nFalse alarms during walking: {false_walking}")

    df.to_csv(HERE/"iforest_results.csv", index=False)

if __name__ == "__main__":
    main()
