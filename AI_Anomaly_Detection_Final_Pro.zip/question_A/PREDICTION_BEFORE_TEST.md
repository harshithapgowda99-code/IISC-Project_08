# Level 3 prediction — write BEFORE running compare_window_sizes.py

My prediction about what will happen to **silent-drift recall** when I double the
rolling window from 60 s to 120 s:

> WRITE YOUR OWN PREDICTION HERE.

Reason:

> WRITE YOUR OWN REASON HERE.

Commit this file before running the test.
