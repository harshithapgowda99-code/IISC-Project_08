from pathlib import Path
import sqlite3
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DB = HERE/"monitoring.db"

df = pd.read_csv(ROOT/"setup"/"readings.csv", parse_dates=["timestamp"])

# Create 3 users with time offsets
users = []
for user_id, seconds in [("user_1", 0), ("user_2", 17), ("user_3", 41)]:
    part = df.copy()
    part["user_id"] = user_id
    part["timestamp"] = part["timestamp"] + pd.to_timedelta(seconds, unit="s")
    users.append(part)
all_df = pd.concat(users, ignore_index=True)

con = sqlite3.connect(DB)
con.executescript((HERE/"schema.sql").read_text())

all_df[["user_id","timestamp","hr","acc","label","anomaly_type"]].to_sql(
    "readings", con, if_exists="append", index=False
)

# Treat labelled anomalous readings as alert source data for SQL exercise.
alerts = all_df[all_df["label"] == 1][
    ["user_id","timestamp","anomaly_type"]
].copy()
alerts["score"] = 1.0
alerts["message"] = "Synthetic labelled anomaly"
alerts.to_sql("alerts", con, if_exists="append", index=False)

queries = {
"1_alerts_per_user_last_24h": """
SELECT user_id, COUNT(*) AS alert_count
FROM alerts
WHERE timestamp >= datetime((SELECT MAX(timestamp) FROM alerts), '-24 hours')
GROUP BY user_id
ORDER BY user_id;
""",
"2_users_more_than_5_alerts_in_one_hour": """
SELECT user_id,
       strftime('%Y-%m-%d %H:00:00', timestamp) AS hour_bucket,
       COUNT(*) AS alert_count
FROM alerts
GROUP BY user_id, hour_bucket
HAVING COUNT(*) > 5
ORDER BY alert_count DESC;
""",
"3_average_hr_per_user_per_hour": """
SELECT user_id,
       strftime('%Y-%m-%d %H:00:00', timestamp) AS hour_bucket,
       ROUND(AVG(hr), 2) AS avg_hr
FROM readings
GROUP BY user_id, hour_bucket
ORDER BY user_id, hour_bucket;
"""
}

with open(HERE/"query_outputs.txt", "w", encoding="utf-8") as f:
    for name, sql in queries.items():
        out = pd.read_sql_query(sql, con)
        print("\n", name)
        print(out.to_string(index=False))
        f.write(f"\n{name}\n{'='*len(name)}\n")
        f.write(out.to_string(index=False))
        f.write("\n")

con.close()
print(f"\nDatabase saved to {DB}")
print(f"Query outputs saved to {HERE/'query_outputs.txt'}")
