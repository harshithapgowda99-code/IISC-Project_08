# Submission Checklist

## Before submission
- [ ] Seed confirmed as `0008` (numeric value `8`).
- [ ] Create a NEW GitHub repository after the assignment post.
- [ ] Make at least four genuine commits spread across the assignment window.
- [ ] Commit `question_A/PREDICTION_BEFORE_TEST.md` BEFORE running the Level-3 window-size experiment.
- [ ] After that commit, run:
      `python question_A/compare_window_sizes.py`
- [ ] Save the output and explain whether the prediction was correct.
- [ ] Complete `PERSONAL_INTELLIGENCE.md` in your own words.
- [ ] Record a 3–5 minute demo video in your own voice.
- [ ] Upload video to Google Drive and set "Anyone with the link can view".
- [ ] Send GitHub + Drive links using the required email subject.

## Recommended demo order
1. README + seed
2. Generated dataset / full_signal.png
3. Isolation Forest results
4. NumPy rolling z-score implementation
5. Own metric function vs sklearn result
6. Level-3 prediction and window-size experiment
7. System architecture
8. SQLite schema and three SQL queries
9. Capacity calculation and 100k-user scaling explanation
