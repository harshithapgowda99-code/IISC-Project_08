import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

N = 7200
FS = 1  # 1 reading per second

def add_non_overlapping_interval(intervals, start, end):
    for a, b in intervals:
        if not (end < a or start > b):
            return False
    intervals.append((start, end))
    return True

def generate(seed: int):
    rng = np.random.default_rng(seed)
    t = np.arange(N)
    baseline = 60 + (seed % 20)

    # Normal HR components
    slow_drift = 2.0 * np.sin(2 * np.pi * t / 3600)
    breathing = 1.5 * np.sin(2 * np.pi * t / 6)
    noise = rng.normal(0, 1.2, N)
    hr = baseline + slow_drift + breathing + noise

    # Accelerometer magnitude: mostly low
    acc = np.abs(rng.normal(0.08, 0.03, N))

    occupied = []
    walking_periods = []

    # Three walking periods, 5-10 min each
    for _ in range(3):
        duration = int(rng.integers(300, 601))
        for _try in range(1000):
            start = int(rng.integers(60, N - duration - 60))
            end = start + duration - 1
            if add_non_overlapping_interval(occupied, start, end):
                walking_periods.append((start, end))
                acc[start:end+1] += rng.normal(1.0, 0.12, duration)
                hr[start:end+1] += rng.uniform(20, 30)
                break

    label = np.zeros(N, dtype=int)
    anomaly_type = np.array(["normal"] * N, dtype=object)

    # Keep anomaly start regions away from walking periods and each other.
    anomaly_events = []
    types = ["spike"] * 7 + ["dropout"] * 7 + ["silent_drift"] * 6
    rng.shuffle(types)

    for typ in types:
        if typ == "spike":
            duration = int(rng.integers(3, 11))
        elif typ == "dropout":
            duration = int(rng.integers(10, 31))
        else:
            duration = 300

        placed = False
        for _try in range(3000):
            start = int(rng.integers(120, N - duration - 120))
            end = start + duration - 1
            # add a safety margin so contextual windows are cleaner
            candidate = (start - 30, end + 30)
            if all(candidate[1] < a or candidate[0] > b for a, b in occupied):
                occupied.append(candidate)
                anomaly_events.append((typ, start, end))

                label[start:end+1] = 1
                anomaly_type[start:end+1] = typ

                if typ == "spike":
                    hr[start:end+1] += rng.uniform(42, 55)
                    acc[start:end+1] = np.minimum(acc[start:end+1], 0.15)
                elif typ == "dropout":
                    if rng.random() < 0.5:
                        hr[start:end+1] = 0.0
                    else:
                        flat = float(hr[start])
                        hr[start:end+1] = flat
                    acc[start:end+1] *= 0.3
                else:
                    hr[start:end+1] += np.linspace(0, 15, duration)
                    acc[start:end+1] = np.minimum(acc[start:end+1], 0.15)

                placed = True
                break
        if not placed:
            raise RuntimeError(f"Could not place anomaly {typ}")

    ts = pd.date_range("2026-10-06 12:00:00", periods=N, freq="s")
    df = pd.DataFrame({
        "timestamp": ts,
        "hr": np.round(hr, 3),
        "acc": np.round(acc, 4),
        "label": label,
        "anomaly_type": anomaly_type
    })

    return df, walking_periods, anomaly_events, baseline

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, required=True)
    args = p.parse_args()

    outdir = Path(__file__).resolve().parent
    df, walking_periods, anomaly_events, baseline = generate(args.seed)
    csv_path = outdir / "readings.csv"
    df.to_csv(csv_path, index=False)

    # Save metadata so downstream scripts can report walking false alarms.
    meta = {
        "seed": args.seed,
        "baseline_hr": baseline,
        "walking_periods": walking_periods,
        "anomaly_events": anomaly_events
    }
    import json
    (outdir / "metadata.json").write_text(json.dumps(meta, indent=2))

    plt.figure(figsize=(14, 5))
    plt.plot(df["timestamp"], df["hr"], linewidth=0.7, label="Heart rate")
    anom = df["label"] == 1
    plt.scatter(df.loc[anom, "timestamp"], df.loc[anom, "hr"], s=7, label="Anomaly")
    plt.xlabel("Time")
    plt.ylabel("Heart rate (bpm)")
    plt.title(f"Generated wearable signal — seed {args.seed}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outdir / "full_signal.png", dpi=160)
    plt.close()

    print(f"Saved {len(df)} rows to {csv_path}")
    print(f"Resting baseline: {baseline} bpm")
    print(f"Walking periods: {walking_periods}")
    print(f"Anomaly events: {len(anomaly_events)}")

if __name__ == "__main__":
    main()
