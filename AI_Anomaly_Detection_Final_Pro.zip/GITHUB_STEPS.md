# GitHub publish steps

After creating a new empty repository on GitHub:

```bash
cd AI_Anomaly_Detection_Final_Project
git init
git add README.md requirements.txt setup question_A/common_metrics.py question_A/isolation_forest.py
git commit -m "Initial dataset generator and anomaly detection"

git add question_A/rolling_zscore.py
git commit -m "Add NumPy rolling detector and custom metrics validation"

# IMPORTANT: edit prediction first, then:
git add question_A/PREDICTION_BEFORE_TEST.md
git commit -m "Record Level 3 prediction before experiment"

# Only AFTER the prediction commit:
python question_A/compare_window_sizes.py

git add question_C PERSONAL_INTELLIGENCE.md DEMO_SCRIPT.md SUBMISSION_CHECKLIST.md
git commit -m "Add SQL system design, scaling analysis and submission notes"

git branch -M main
git remote add origin <YOUR_NEW_REPOSITORY_URL>
git push -u origin main
```

Do not fabricate commit timing. Use your genuine commits and your own prediction.
