USERS = 1000
READINGS_PER_SEC_PER_USER = 1
SECONDS_PER_DAY = 24 * 60 * 60
DAYS_PER_MONTH = 30

rows_per_day = USERS * READINGS_PER_SEC_PER_USER * SECONDS_PER_DAY
writes_per_second = USERS * READINGS_PER_SEC_PER_USER

# State your assumed row size clearly. Example estimate:
# timestamp 8 + user_id/keys ~16 + hr 8 + acc 8 + labels/overhead/index allowance ~60
BYTES_PER_ROW_ESTIMATE = 100

bytes_per_month = rows_per_day * DAYS_PER_MONTH * BYTES_PER_ROW_ESTIMATE
gb_per_month = bytes_per_month / (1024**3)

print(f"Users: {USERS:,}")
print(f"Rows/day = {USERS:,} users × 1 row/s × 86,400 s = {rows_per_day:,}")
print(f"Writes/second = {writes_per_second:,}")
print(f"Assumed storage/row = {BYTES_PER_ROW_ESTIMATE} bytes")
print(f"Storage/month ≈ {gb_per_month:.2f} GiB")

print("\nAt 100,000 users:")
u2 = 100_000
print(f"Rows/day = {u2 * SECONDS_PER_DAY:,}")
print(f"Writes/second = {u2:,}")
print(f"Storage/month ≈ {(u2*SECONDS_PER_DAY*DAYS_PER_MONTH*BYTES_PER_ROW_ESTIMATE)/(1024**3):.2f} GiB")
print("\nReasoning to explain in your own words:")
print("- A single SQLite/MySQL instance will become the first bottleneck at sustained ingest.")
print("- Move ingestion through a queue/stream, batch writes, partition time-series storage,")
print("  and scale detectors horizontally by user/partition.")
