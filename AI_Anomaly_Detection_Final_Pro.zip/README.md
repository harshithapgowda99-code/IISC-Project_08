# AI-Driven Anomaly Detection and Monitoring System

## IMPORTANT
Replace `8` with the last four digits of your USN and use the same seed everywhere.

Recommended submission path in this starter:
- Common setup
- Question A: anomaly detection
- Question C: full-system design + SQL

## Run order

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt

python setup/generate_data.py --seed 8
python question_A/isolation_forest.py --seed 8
python question_A/rolling_zscore.py --window 60
python question_A/compare_window_sizes.py
python question_C/load_and_query.py
python question_C/capacity_math.py
```

## Required personal work before submission
1. Put your actual seed in this README.
2. Before running the Level 3 window-size test, write your prediction in
   `question_A/PREDICTION_BEFORE_TEST.md` and commit it to GitHub.
3. Fill `PERSONAL_INTELLIGENCE.md` using your own results.
4. Inspect all outputs/plots and make sure you can explain each function.
5. Make at least four commits spread across the assignment window.




## Seed
Official USN seed: `0008`.
For Python/NumPy/scikit-learn random-state usage, `0008` is the integer `8`, so the generated dataset and model results are unchanged.
