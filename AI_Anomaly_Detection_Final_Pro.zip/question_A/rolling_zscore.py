import argparse, sys, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
from common_metrics import precision_recall_f1

def rolling_mean_std_numpy(x, window):
    """
    Mean/std of the PREVIOUS `window` values for each index.
    No pandas rolling and no sklearn.
    """
    x = np.asarray(x, dtype=float)
    n = len(x)
    means = np.full(n, np.nan)
    stds = np.full(n, np.nan)

    # Prefix sums => O(n)
    cs = np.concatenate([[0.0], np.cumsum(x)])
    cs2 = np.concatenate([[0.0], np.cumsum(x * x)])

    for i in range(n):
        start = max(0, i - window)
        count = i - start
        if count < 5:
            continue
        s = cs[i] - cs[start]
        s2 = cs2[i] - cs2[start]
        mean = s / count
        var = max(0.0, (s2 / count) - mean * mean)
        means[i] = mean
        stds[i] = np.sqrt(var)
    return means, stds

def detect(df, window=60, z_threshold=3.5):
    hr = df["hr"].to_numpy(float)
    acc = df["acc"].to_numpy(float)
    mean, std = rolling_mean_std_numpy(hr, window)
    std = np.where((std < 1e-6) | np.isnan(std), 1.0, std)
    z = np.abs((hr - mean) / std)
    z[np.isnan(z)] = 0.0

    # HR deviation should occur while movement is low.
    point_spike = (z >= z_threshold) & (acc < 0.35)

    # Dropout rule: zero OR near-flat recent sequence.
    dropout = np.zeros(len(hr), dtype=bool)
    for i in range(9, len(hr)):
        recent = hr[i-9:i+1]
        if np.all(recent == 0) or np.std(recent) < 0.05:
            dropout[i] = True

    # Slow drift cue: compare current HR with mean ~5 min earlier while movement low.
    silent = np.zeros(len(hr), dtype=bool)
    lag = 300
    if len(hr) > lag:
        rise = hr[lag:] - hr[:-lag]
        silent[lag:] = (rise >= 10.0) & (acc[lag:] < 0.35)

    pred = point_spike | dropout | silent
    return pred.astype(int), z

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--window", type=int, default=60)
    p.add_argument("--threshold", type=float, default=3.5)
    args = p.parse_args()

    df = pd.read_csv(ROOT/"setup"/"readings.csv")
    pred, z = detect(df, args.window, args.threshold)
    df["zscore_pred"] = pred
    df["zscore"] = z

    print(f"Rolling z-score detector: window={args.window}, threshold={args.threshold}")
    for typ in ["spike", "dropout", "silent_drift"]:
        y_true = (df["anomaly_type"] == typ).astype(int).to_numpy()
        p1, r1, f1, *_ = precision_recall_f1(y_true, pred)

        # Verify our metric function against sklearn
        p2, r2, f2, _ = precision_recall_fscore_support(
            y_true, pred, average="binary", zero_division=0
        )
        print(f"{typ:14s} ours=({p1:.3f},{r1:.3f},{f1:.3f}) "
              f"sklearn=({p2:.3f},{r2:.3f},{f2:.3f})")

    meta = json.loads((ROOT/"setup"/"metadata.json").read_text())
    walking_mask = np.zeros(len(df), dtype=bool)
    for start, end in meta["walking_periods"]:
        walking_mask[start:end+1] = True
    print("False alarms during walking:", int(pred[walking_mask].sum()))
    df.to_csv(HERE/f"zscore_results_w{args.window}.csv", index=False)

if __name__ == "__main__":
    main()
