# 3–5 Minute Demo Script

## 0:00–0:30 — Project overview
"This project detects abnormal patterns in wearable heart-rate and movement data.
I selected Question A for anomaly detection and Question C for system design and SQL."

## 0:30–1:10 — Dataset
"The generator creates 7,200 readings, representing two hours at one reading per second.
My USN seed is 0008, which is numeric seed 8, giving a resting baseline of 68 bpm.
Walking raises heart rate but is intentionally normal. The data contains 20 anomaly events:
spikes, drop-outs and silent drifts."

Show: `setup/full_signal.png`

## 1:10–2:15 — Question A
"For Level 1 I used Isolation Forest. It detects spikes well but produces many walking false
alarms and performs poorly on silent drift.

For Level 2 I implemented a rolling detector using NumPy. I used prefix sums to compute
historical mean and standard deviation without pandas rolling. I also wrote my own
precision, recall and F1 implementation and checked that its values match sklearn."

Current seed-8 results:
- Isolation Forest spike recall: 1.000
- Isolation Forest dropout recall: 0.253
- Isolation Forest silent-drift recall: 0.001
- Isolation Forest walking false alarms: 405

- Custom detector spike recall: 1.000
- Custom detector dropout recall: 0.679
- Custom detector silent-drift recall: 0.317
- Custom detector walking false alarms: 0

For Level 3, show your prediction commit first, then run the 60-vs-120-second test and
explain whether your prediction matched the measured result.

## 2:15–3:30 — Question C
"The architecture separates ingestion, streaming, storage, detection and notifications.
For the local demo I used SQLite. I loaded the dataset as three users with time offsets
and ran the three required SQL queries."

Show: `question_C/architecture.md`, `schema.sql`, `query_outputs.txt`

## 3:30–4:20 — Scaling
"For 1,000 users at one reading per second:
- 1,000 writes/second
- 86.4 million rows/day
- about 241.4 GiB/month assuming 100 bytes per stored row.

At 100,000 users that becomes 100,000 writes/second and roughly 23.6 TiB/month.
A single database becomes the main bottleneck, so I would introduce a message queue,
batch writes, partitioned time-series storage and horizontally scaled detection workers."

## 4:20–5:00 — Personal reasoning
Finish with your two decisions per question and your AI-use declaration from
`PERSONAL_INTELLIGENCE.md`.
