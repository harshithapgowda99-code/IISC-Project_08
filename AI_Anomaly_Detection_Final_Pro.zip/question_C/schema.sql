DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS readings;

CREATE TABLE readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    timestamp DATETIME NOT NULL,
    hr REAL NOT NULL,
    acc REAL NOT NULL,
    label INTEGER NOT NULL,
    anomaly_type TEXT NOT NULL
);

CREATE INDEX idx_readings_user_time
ON readings(user_id, timestamp);

CREATE TABLE alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    timestamp DATETIME NOT NULL,
    anomaly_type TEXT NOT NULL,
    score REAL,
    message TEXT
);

CREATE INDEX idx_alerts_user_time
ON alerts(user_id, timestamp);
