from pathlib import Path
import sys
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
from rolling_zscore import detect
from common_metrics import precision_recall_f1

df = pd.read_csv(ROOT/"setup"/"readings.csv")
y = (df["anomaly_type"] == "silent_drift").astype(int).to_numpy()

for w in [60, 120]:
    pred, _ = detect(df, window=w)
    p, r, f1, *_ = precision_recall_f1(y, pred)
    print(f"window={w:3d}: silent_drift precision={p:.3f}, recall={r:.3f}, f1={f1:.3f}")

print("\nCompare this result with the prediction you committed BEFORE running this script.")
