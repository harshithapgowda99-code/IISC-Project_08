# Question C — Level 1 architecture

```text
Wearable Devices (1 reading/sec/user)
        |
        v
HTTPS / MQTT Ingestion API
        |
        v
Message Queue / Stream
        |
        +------------------> Raw Readings Store
        |
        v
Anomaly Detection Workers
        |
        +------------------> Alerts Table
        |
        +------------------> Notification Service
        |                       |
        |                       +--> Email / SMS / App alert
        |
        v
Dashboard / API
```

## Why this structure?
- Ingestion is separated from detection so short detector slowdowns do not lose readings.
- Raw data and alerts are stored separately.
- Detection workers can scale independently.
- Dashboard reads stored data/results rather than blocking ingestion.

For the local assignment demo, SQLite is enough. In the 100,000-user discussion,
explain what you would replace and why.
